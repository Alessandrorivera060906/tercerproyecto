import tkinter as tk
from tkinter import ttk, messagebox
import re
from dataclasses import dataclass, field
from typing import Dict, Tuple, Set, List, Optional

# -------------------------
# Máquina de Turing
# -------------------------

Move = str              
TransitionKey = Tuple[str, str]
TransitionVal = Tuple[str, str, Move] 

@dataclass
class TuringMachine:
    states: Set[str]
    input_alphabet: Set[str]
    tape_alphabet: Set[str]
    blank: str
    transitions: Dict[TransitionKey, TransitionVal]
    start_state: str
    accept_states: Set[str]
    reject_states: Set[str] = field(default_factory=set)

    tape: Dict[int, str] = field(default_factory=dict)  
    head: int = 0
    state: str = ""
    halted: bool = False
    accepted: Optional[bool] = None

    def reset(self, input_string: str):
        self.tape = {i: ch for i, ch in enumerate(input_string)}
        self.head = 0
        self.state = self.start_state
        self.halted = False
        self.accepted = None

    def read(self) -> str:
        return self.tape.get(self.head, self.blank)

    def write(self, symbol: str):
        self.tape[self.head] = symbol

    def step(self) -> bool:
        if self.halted:
            return False
        sym = self.read()
        key = (self.state, sym)
        if key not in self.transitions:
            self.halted = True
            self.accepted = (self.state in self.accept_states)
            return False
        next_state, write_sym, move = self.transitions[key]
        self.write(write_sym)
        if move == 'R':
            self.head += 1
        elif move == 'L':
            self.head -= 1
        self.state = next_state
        return True


# -------------------------
# Constructor DFA -> MT lectora
# -------------------------
def tm_from_dfa(
    states: Set[str],
    alphabet: Set[str],
    start: str,
    accepts: Set[str],
    delta: Dict[Tuple[str, str], str],
    blank: str = '□'
) -> TuringMachine:
    transitions: Dict[TransitionKey, TransitionVal] = {}
    tape_alphabet = set(alphabet) | {blank}
    for (q, a), p in delta.items():
        transitions[(q, a)] = (p, a, 'R')  
    return TuringMachine(
        states=states,
        input_alphabet=alphabet,
        tape_alphabet=tape_alphabet,
        blank=blank,
        transitions=transitions,
        start_state=start,
        accept_states=accepts,
    )


# -------------------------
# 5 MT predefinidas (regulares)
# -------------------------
def build_predefined_machines():
    machines = {}

    # 1) (ab)*
    states = {'q0', 'q1', 'qd'}
    alphabet = {'a', 'b'}
    start = 'q0'
    accepts = {'q0'}
    delta = {
        ('q0', 'a'): 'q1',
        ('q0', 'b'): 'qd',
        ('q1', 'a'): 'qd',
        ('q1', 'b'): 'q0',
        ('qd', 'a'): 'qd',
        ('qd', 'b'): 'qd',
    }
    machines['(ab)*'] = tm_from_dfa(states, alphabet, start, accepts, delta)

    # 2) 0*1*
    states = {'q0', 'q1', 'qd'}
    alphabet = {'0', '1'}
    start = 'q0'
    accepts = {'q0', 'q1'}
    delta = {
        ('q0', '0'): 'q0',
        ('q0', '1'): 'q1',
        ('q1', '1'): 'q1',
        ('q1', '0'): 'qd',
        ('qd', '0'): 'qd',
        ('qd', '1'): 'qd',
    }
    machines['0*1*'] = tm_from_dfa(states, alphabet, start, accepts, delta)

    # 3) (a|b)*abb
    states = {'q0', 'q1', 'q2', 'q3'}
    alphabet = {'a', 'b'}
    start = 'q0'
    accepts = {'q3'}
    delta = {
        ('q0', 'a'): 'q1', ('q0', 'b'): 'q0',
        ('q1', 'a'): 'q1', ('q1', 'b'): 'q2',
        ('q2', 'a'): 'q1', ('q2', 'b'): 'q3',
        ('q3', 'a'): 'q1', ('q3', 'b'): 'q0',
    }
    machines['(a|b)*abb'] = tm_from_dfa(states, alphabet, start, accepts, delta)

    # 4) 1(01)*0
    states = {'q0', 'q1', 'q2', 'qd'}
    alphabet = {'0', '1'}
    start = 'q0'
    accepts = {'q2'}
    delta = {
        ('q0', '1'): 'q1', ('q0', '0'): 'qd',
        ('q1', '0'): 'q2', ('q1', '1'): 'qd',
        ('q2', '1'): 'q1', ('q2', '0'): 'qd',
        ('qd', '0'): 'qd', ('qd', '1'): 'qd',
    }
    machines['1(01)*0'] = tm_from_dfa(states, alphabet, start, accepts, delta)

    # 5) (a|b)*a(a|b)*
    states = {'q0', 'qA'}
    alphabet = {'a', 'b'}
    start = 'q0'
    accepts = {'qA'}
    delta = {
        ('q0', 'a'): 'qA', ('q0', 'b'): 'q0',
        ('qA', 'a'): 'qA', ('qA', 'b'): 'qA',
    }
    machines['(a|b)*a(a|b)*'] = tm_from_dfa(states, alphabet, start, accepts, delta)

    return machines

PREDEFINED_MACHINES = build_predefined_machines()

# 10 regex para pruebas con re.fullmatch
REGEX_TESTS = [
    (r'(a|b)*abb', 'a/b'),
    (r'0*1*', '0/1'),
    (r'(ab)*', 'a/b'),
    (r'1(01)*0', '0/1'),
    (r'(a|b)*a(a|b)*', 'a/b'),
    (r'a*b*a*', 'a/b'),
    (r'(0|1)*00(0|1)*', '0/1'),
    (r'(aa|bb)*', 'a/b'),
    (r'a+', 'a/b'),
    (r'ε|', 'a/b'),  # tratar 'ε' como vacío en UI
]

# -------------------------
# Interfaz (Tk)
# -------------------------
CELL_SPAN = 31
CENTER = CELL_SPAN // 2

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Simulador de Máquina de Turing — Paso a paso")
        self.geometry("980x540")
        self.configure(padx=10, pady=10)

        self.tm: Optional[TuringMachine] = None
        self.running = False
        self.step_delay_ms = 300  

        self._build_widgets()

    def _build_widgets(self):
        top = ttk.Frame(self); top.pack(fill='x', pady=(0,10))

        ttk.Label(top, text="Entrada:").grid(row=0, column=0, sticky='w')
        self.entry_input = ttk.Entry(top, width=40)
        self.entry_input.grid(row=0, column=1, padx=5)
        ttk.Button(top, text="Cargar", command=self.on_load).grid(row=0, column=2, padx=5)

        ttk.Label(top, text="MT predefinida:").grid(row=0, column=3, sticky='e', padx=(20,2))
        self.combo_mt = ttk.Combobox(top, values=list(PREDEFINED_MACHINES.keys()),
                                     state="readonly", width=22)
        self.combo_mt.grid(row=0, column=4)
        self.combo_mt.set('(ab)*')

        ctrl = ttk.Frame(self); ctrl.pack(fill='x', pady=(0,10))
        self.btn_step = ttk.Button(ctrl, text="Paso", command=self.on_step, width=10)
        self.btn_run  = ttk.Button(ctrl, text="Auto", command=self.on_run_toggle, width=10)
        self.btn_reset= ttk.Button(ctrl, text="Reiniciar", command=self.on_reset, width=10)
        self.btn_step.pack(side='left')
        self.btn_run.pack(side='left', padx=5)
        self.btn_reset.pack(side='left')

        state_frame = ttk.Frame(self); state_frame.pack(fill='x', pady=(0,10))
        self.var_state  = tk.StringVar(value="Estado: —")
        self.var_status = tk.StringVar(value="")
        ttk.Label(state_frame, textvariable=self.var_state,  font=("Segoe UI", 12, "bold")).pack(side='left')
        ttk.Label(state_frame, textvariable=self.var_status, foreground="#444").pack(side='left', padx=15)

        tape_frame = ttk.LabelFrame(self, text="Cinta"); tape_frame.pack(fill='both', expand=True)
        grid = ttk.Frame(tape_frame); grid.pack(fill='x', pady=4)
        self.tape_labels: List[tk.Label] = []
        for i in range(CELL_SPAN):
            lbl = tk.Label(grid, text="□", width=2, relief='groove', borderwidth=1, font=("Consolas", 14))
            lbl.grid(row=0, column=i, padx=1, pady=1)
            self.tape_labels.append(lbl)

        footer = ttk.Frame(tape_frame); footer.pack(fill='x', pady=2)
        self.index_labels: List[tk.Label] = []
        for i in range(CELL_SPAN):
            il = tk.Label(footer, text="", width=3, font=("Consolas", 9), fg="#666")
            il.grid(row=0, column=i)
            self.index_labels.append(il)

        # Panel de regex
        right = ttk.LabelFrame(self, text="Pruebas con Expresiones Regulares (10)")
        right.pack(fill='x', pady=6)
        self.combo_regex = ttk.Combobox(right, values=[p for p,_ in REGEX_TESTS], state="readonly", width=30)
        self.combo_regex.grid(row=0, column=0, padx=5, pady=5)
        self.combo_regex.set(REGEX_TESTS[0][0])

        ttk.Label(right, text="Cadena:").grid(row=0, column=1, sticky='e')
        self.entry_regex = ttk.Entry(right, width=30); self.entry_regex.grid(row=0, column=2, padx=5)

        ttk.Button(right, text="Evaluar (re.fullmatch)", command=self.eval_regex).grid(row=0, column=3, padx=5)
        ttk.Button(right, text="Cargar MT equivalente si existe", command=self.load_mt_for_regex).grid(row=0, column=4, padx=5)
        self.label_regex_out = ttk.Label(right, text=""); self.label_regex_out.grid(row=1, column=0, columnspan=5, sticky='w', padx=6, pady=(0,6))

        self.on_load()

    # -------------------------
    # Callbacks de interfaz
    # -------------------------
    def on_load(self):
        name = self.combo_mt.get()
        self.tm = PREDEFINED_MACHINES[name]
        s = self.entry_input.get()
        if self.combo_regex.get() == 'ε|' and s == 'ε':
            s = ""
        self.tm.reset(s)
        self.var_status.set(f"Cargada MT: {name}")
        self.refresh_view()

    def on_reset(self):
        if self.tm:
            self.on_load()

    def on_step(self):
        if self.tm and not self.tm.halted:
            self.tm.step()
        self.refresh_view()

    def on_run_toggle(self):
        if not self.tm:
            return
        self.running = not self.running
        self.btn_run.config(text="Pausar" if self.running else "Auto")
        if self.running:
            self._run_loop()

    def _run_loop(self):
        if not self.running or not self.tm or self.tm.halted:
            self.refresh_view()
            return
        self.tm.step()
        self.refresh_view()
        self.after(self.step_delay_ms, self._run_loop)

    def refresh_view(self):
        if not self.tm:
            return
        status = ""
        if self.tm.halted:
            status = "Resultado: ACEPTADA" if self.tm.accepted else "Resultado: RECHAZADA"
        self.var_status.set(status)
        self.var_state.set(f"Estado: {self.tm.state}  |  Cabezal: {self.tm.head}")

        start = self.tm.head - CENTER
        for i in range(CELL_SPAN):
            idx = start + i
            ch = self.tm.tape.get(idx, self.tm.blank)
            lbl = self.tape_labels[i]
            lbl.config(text=ch, bg=("#FFEB8A" if idx == self.tm.head else self.cget("bg")))
            self.index_labels[i].config(text=str(idx))

    # -------------------------
    # Regex (referencia)
    # -------------------------
    def eval_regex(self):
        pat = self.combo_regex.get()
        s = self.entry_regex.get()
        if pat == 'ε|' and s == 'ε':
            s, pat = "", r''
        try:
            ok = re.fullmatch(pat, s) is not None
            self.label_regex_out.config(text=f"[Regex] «{pat}»  =>  {'ACEPTA' if ok else 'RECHAZA'}")
        except re.error as e:
            messagebox.showerror("Regex inválida", str(e))

    def load_mt_for_regex(self):
        mapping = {
            '(a|b)*abb': '(a|b)*abb',
            '0*1*': '0*1*',
            '(ab)*': '(ab)*',
            '1(01)*0': '1(01)*0',
            '(a|b)*a(a|b)*': '(a|b)*a(a|b)*',
        }
        pat = self.combo_regex.get()
        if pat not in mapping:
            messagebox.showinfo("No disponible", "No hay MT predefinida para esa regex.")
            return
        self.combo_mt.set(mapping[pat])
        self.entry_input.delete(0, tk.END)
        self.entry_input.insert(0, self.entry_regex.get())
        self.on_load()

if __name__ == "__main__":
    App().mainloop()
